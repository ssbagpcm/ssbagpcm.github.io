import webview
import os

def main():
    # Chemin vers le fichier HTML local
    chemin_fichier = os.path.abspath("sguibeta.html")  # Remplacez par le chemin de votre fichier

    # Création de la fenêtre Webview sans barre de titre
    window = webview.create_window(
        title='',
        url=chemin_fichier,
        width=1024,
        height=768,
        resizable=True,
        fullscreen=False,
        background_color='#FFFFFF'
    )
    
    # Démarrage de l'application
    webview.start()

if __name__ == "__main__":
    main()
